# Void CLI-Game Manager

Welcome to Void, a game manager specialized for CLI terminal games designed to enhance your gaming experience. With Void, you can easily manage and play your favorite CLI games all in one place.